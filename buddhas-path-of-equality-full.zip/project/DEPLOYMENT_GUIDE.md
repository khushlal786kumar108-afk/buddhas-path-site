# 🕊️ Buddha's Path of Equality — Deployment Guide (Beginner / Mobile)

Written for doing this entirely from an Android phone using Chrome.
Everything below uses website dashboards — no command-line tools
required on your phone.

**The big picture:** you're deploying two separate things —
`site/` (the website people see, goes to **Vercel**) and `server/`
(the backend that handles logins/OTP/database, goes to **Render**).
They connect through one file: `site/config.js`.

---

## Before you start: get the code onto GitHub

Both Vercel and Render deploy from a GitHub repository — this is the
easiest path on mobile (no terminal needed).

1. On your phone, go to **github.com**, sign in (or create a free account).
2. Tap **+** → **New repository**. Name it e.g. `buddhas-path-of-equality`. Keep it **Public** or **Private**, either works. Tap **Create repository**.
3. Unzip the ZIP file I gave you (Android's Files app can unzip — tap the zip, tap "Extract").
4. In your new GitHub repo, tap **Add file → Upload files**.
5. From your Files app, select **everything inside the `project` folder** (both the `site` folder and `server` folder together) and upload. GitHub's mobile web upload handles folders fine in Chrome.
6. Scroll down, tap **Commit changes**.

You now have one repo containing both `site/` and `server/` as subfolders — that's exactly what both Vercel and Render expect for step 1 and 2 below.

---

## 1. Deploy `site/` to Vercel

1. Go to **vercel.com** in Chrome, sign in with your GitHub account.
2. Tap **Add New → Project**.
3. Select your `buddhas-path-of-equality` repo → tap **Import**.
4. You'll see a **Root Directory** field — tap **Edit**, choose/type `site`. This is the single most important setting; without it the site won't render correctly.
5. Framework Preset: leave as **Other**.
6. Build Command / Output Directory / Install Command: leave blank (a `vercel.json` inside `site/` already tells Vercel not to run a build step).
7. Tap **Deploy**. Wait ~30–60 seconds.
8. You'll get a URL like `https://buddhas-path-of-equality.vercel.app`. Open it — the site should look fully styled with all images. (Registration/login won't work yet — that's expected until step 6.)

---

## 2. Deploy `server/` to Render

1. Go to **render.com**, sign in with GitHub.
2. Tap **New +** → **Web Service**.
3. Select the same `buddhas-path-of-equality` repo.
4. **Root Directory**: type `server`.
5. **Runtime**: Node.
6. **Build Command**: `npm install && npx prisma generate && npx prisma migrate deploy`
7. **Start Command**: `npm start`
8. **Instance Type**: Free is fine to start.
9. Don't tap Deploy yet — first do step 3 (database) and step 4 (env vars) below, then come back and deploy.

---

## 3. Create and configure the database

SQLite (the local default) does **not** reliably survive restarts on
Render's free tier, so use a real Postgres database for production:

1. In Render, tap **New +** → **PostgreSQL**.
2. Give it a name, choose the Free plan, tap **Create Database**.
3. Once created, open it and copy the **Internal Database URL** (starts with `postgresql://...`).
4. One code edit is required here — open `server/prisma/schema.prisma` in GitHub's mobile editor (navigate to the file, tap the pencil icon) and change:
   ```
   provider = "sqlite"
   ```
   to
   ```
   provider = "postgresql"
   ```
   Commit the change. This is the one line that must change for a real production database — everything else in the code already supports Postgres with no other edits.

---

## 4. Where to add JWT_SECRET, DATABASE_URL, SMTP and Twilio variables

Back in your Render **Web Service** (not the database) → tap the
**Environment** tab → **Add Environment Variable**, one at a time:

| Key | Value |
|---|---|
| `NODE_ENV` | `production` |
| `DATABASE_URL` | paste the Postgres URL from step 3 |
| `JWT_SECRET` | any long random string — 40+ random characters |
| `JWT_EXPIRES_IN` | `7d` |
| `COOKIE_NAME` | `bpe_session` |
| `CORS_ORIGIN` | your Vercel URL from step 1, e.g. `https://buddhas-path-of-equality.vercel.app` |
| `ADMIN_EMAIL` | your admin login email |
| `ADMIN_PASSWORD` | a strong password — change it later |
| `ADMIN_NAME` | `Khush Lal Kumar` |
| `FRONTEND_RESET_URL` | your Vercel URL + `/index.html` |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `EMAIL_FROM` | from your email provider (see below) |
| `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER` | from your Twilio console (see below) |
| `DEV_LOG_OTP_TO_CONSOLE` | `false` (keep `true` only while testing without real SMTP/Twilio yet) |

**Where SMTP values come from:** the simplest option is a Gmail
account with an **App Password** (Google Account → Security → App
Passwords). `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`.

**Where Twilio values come from:** sign up free at twilio.com on
your phone browser, verify your own number, and your Account SID,
Auth Token, and a trial phone number appear right on the Twilio
console home page.

Now tap **Create Web Service** (or **Deploy** if you already created it) to actually deploy.

---

## 5. How to get the deployed backend URL

Once Render finishes deploying (watch the **Logs** tab — wait for
"🕊️ Buddha's Path of Equality API listening..."), the URL is shown
at the top of the service page, e.g.:

```
https://buddhas-path-of-equality-api.onrender.com
```

Test it works: open `https://your-service.onrender.com/api/health`
in your phone browser — you should see `{"ok":true,"env":"production"}`.

Then, still in Render, open the **Shell** tab (works from mobile
browser) and run once:
```
npm run seed:admin
```
This creates your admin login from the `ADMIN_EMAIL`/`ADMIN_PASSWORD` you set in step 4.

---

## 6. Where to put that backend URL in site/config.js

1. In GitHub, navigate to `site/config.js`, tap the pencil (edit) icon.
2. Find this line:
   ```js
   const API_BASE_URL = 'https://your-backend-domain.example.com/api';
   ```
3. Replace it with your real Render URL **plus `/api` at the end**:
   ```js
   const API_BASE_URL = 'https://buddhas-path-of-equality-api.onrender.com/api';
   ```
4. Commit the change directly on GitHub's `main` branch.
5. Vercel automatically redeploys within about a minute whenever you push to GitHub — no extra step needed on Vercel's side.

---

## 7. How to download the final ZIP and use it

1. Tap the ZIP file I shared in this chat to download it to your phone.
2. Open your Files app → find the ZIP in Downloads → tap it → **Extract**.
3. You'll get a `project` folder containing `site/` and `server/` — this is what you upload to GitHub in the "Before you start" section above.
4. Keep this folder as your backup/reference — if you ever need to re-upload or compare files, it's your clean source copy.

---

## 8. Testing registration → OTP → PDF → auto-login → dashboard

Once steps 1–6 are all done:

1. Open your **Vercel URL** on your phone.
2. Tap **Join Our Community** → fill in name, real email, real mobile number (with country code, e.g. `+91...`), a password → submit.
3. You'll land on a **Verify Your Account** screen showing your masked email/mobile.
4. Check the email inbox you registered with for a 6-digit code, and check your phone's SMS for the other 6-digit code. (If `DEV_LOG_OTP_TO_CONSOLE=true` and SMTP/Twilio aren't set up yet, open Render's **Logs** tab instead — the codes print there, clearly labelled `[DEV ONLY]`.)
5. Enter both codes → **Verify & Continue**.
6. You should immediately see a success screen with your real Registration ID.
7. Tap **📄 Download Registration PDF** — this downloads a real PDF generated by the backend, containing your actual submitted name, email, and Registration ID (never your password).
8. Tap **Go to My Dashboard** — you're already logged in (the session was created automatically the moment your OTP verified), so the dashboard loads your real profile immediately, no separate login step needed.
9. To confirm login/logout separately: tap **Logout**, then **Continue Your Journey** → log in again with the same email/password → you should land back on the dashboard.

If anything shows "Can't reach the server," it means `config.js`'s
URL doesn't match your Render URL exactly, or Render's free-tier
service is asleep (free services sleep after inactivity and take
~30–60 seconds to wake on the first request — just wait and retry).
