# 🕊️ Buddha's Path of Equality ☸️ — Full Project

```
buddhas-path-of-equality/
├── site/     ← the frontend (open site/index.html, see site/README.md)
└── server/   ← the real backend API (see server/README.md — start here first)
```

## Quick start

```bash
# 1. Backend
cd server
npm install
cp .env.example .env         # then edit .env — see server/README.md section 1-2
npx prisma migrate dev --name init
npm run seed:admin
npm run dev                  # → http://localhost:4000

# 2. Frontend (in a second terminal)
cd site
python3 -m http.server 5500  # → http://localhost:5500/index.html
```

Then open `http://localhost:5500/index.html` in your browser.

Read `server/README.md` first — it lists exactly which outside
services (database, email, SMS) you need and where to get them.
