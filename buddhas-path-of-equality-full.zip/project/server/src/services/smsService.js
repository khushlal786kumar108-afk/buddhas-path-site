const env = require('../config/env');

let twilioClient = null;
function getTwilioClient() {
  if (twilioClient) return twilioClient;
  if (!env.TWILIO_ACCOUNT_SID || !env.TWILIO_AUTH_TOKEN) return null;
  // Lazily required so the app can boot even if twilio isn't
  // installed/configured yet in early development.
  const twilio = require('twilio');
  twilioClient = twilio(env.TWILIO_ACCOUNT_SID, env.TWILIO_AUTH_TOKEN);
  return twilioClient;
}

/**
 * Sends an SMS via Twilio. Requires TWILIO_ACCOUNT_SID,
 * TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER in .env.
 *
 * SWAPPING PROVIDERS: if you'd rather use an India-first SMS
 * provider (MSG91, Fast2SMS, etc.) instead of Twilio, this is the
 * only file to change — replace the body of sendSms() with that
 * provider's API call and keep the same function signature so
 * nothing else in the app needs to change.
 */
async function sendSms({ to, body }) {
  const client = getTwilioClient();
  if (!client) {
    const msg = 'SMS service is not configured (missing TWILIO_ACCOUNT_SID/TWILIO_AUTH_TOKEN in .env).';
    if (env.DEV_LOG_OTP_TO_CONSOLE) {
      console.warn(`[smsService] ${msg} — logging content instead:\n  To: ${to}\n  Body: ${body}`);
      return { simulated: true };
    }
    throw new Error(msg);
  }
  return client.messages.create({ to, from: env.TWILIO_FROM_NUMBER, body });
}

async function sendOtpSms(to, code) {
  return sendSms({
    to,
    body: `Buddha's Path of Equality: your verification code is ${code}. It expires in ${env.OTP_EXPIRY_MINUTES} minutes. Do not share it.`,
  });
}

module.exports = { sendSms, sendOtpSms };
