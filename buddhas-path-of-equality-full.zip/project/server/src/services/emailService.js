const nodemailer = require('nodemailer');
const env = require('../config/env');

let transporter = null;
function getTransporter() {
  if (transporter) return transporter;
  if (!env.SMTP_HOST || !env.SMTP_USER || !env.SMTP_PASS) {
    return null; // not configured yet — see sendEmail() fallback below
  }
  transporter = nodemailer.createTransport({
    host: env.SMTP_HOST,
    port: env.SMTP_PORT,
    secure: env.SMTP_SECURE,
    auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
  });
  return transporter;
}

/**
 * Sends an email. Requires SMTP_HOST/SMTP_USER/SMTP_PASS in .env.
 * Any SMTP-speaking provider works here: a Gmail App Password,
 * Postmark, SendGrid's SMTP relay, Zoho Mail, your own mail server,
 * etc. — nothing in this file is provider-specific.
 */
async function sendEmail({ to, subject, html, text }) {
  const t = getTransporter();
  if (!t) {
    const msg = 'Email service is not configured (missing SMTP_HOST/SMTP_USER/SMTP_PASS in .env).';
    if (env.DEV_LOG_OTP_TO_CONSOLE) {
      console.warn(`[emailService] ${msg} — logging content instead:\n  To: ${to}\n  Subject: ${subject}\n  Text: ${text}`);
      return { simulated: true };
    }
    throw new Error(msg);
  }
  return t.sendMail({ from: env.EMAIL_FROM, to, subject, html, text });
}

async function sendOtpEmail(to, code) {
  return sendEmail({
    to,
    subject: 'Your Buddha\'s Path of Equality verification code',
    text: `Your verification code is ${code}. It expires in ${env.OTP_EXPIRY_MINUTES} minutes. Do not share this code with anyone.`,
    html: `<p>🕊️ <b>Buddha's Path of Equality</b></p><p>Your verification code is:</p><p style="font-size:28px;font-weight:700;letter-spacing:4px;">${code}</p><p>This code expires in ${env.OTP_EXPIRY_MINUTES} minutes. Do not share it with anyone.</p>`,
  });
}

async function sendPasswordResetEmail(to, resetUrl) {
  return sendEmail({
    to,
    subject: 'Reset your Buddha\'s Path of Equality password',
    text: `Reset your password using this link (valid for 30 minutes): ${resetUrl}`,
    html: `<p>Reset your password using the link below (valid for 30 minutes):</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>If you did not request this, you can safely ignore this email.</p>`,
  });
}

module.exports = { sendEmail, sendOtpEmail, sendPasswordResetEmail };
