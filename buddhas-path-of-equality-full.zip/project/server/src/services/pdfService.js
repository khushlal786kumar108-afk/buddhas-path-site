const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const STORAGE_DIR = path.join(__dirname, '..', '..', 'storage', 'documents');
const LOGO_PATH = path.join(__dirname, '..', '..', '..', 'site', 'assets', 'images', 'logo.png');

if (!fs.existsSync(STORAGE_DIR)) fs.mkdirSync(STORAGE_DIR, { recursive: true });

/**
 * Generates a professional registration confirmation PDF for a
 * verified user and saves it under storage/documents. Never include
 * passwords, OTP codes, or other secrets in this document.
 *
 * Returns { filename, filePath } — filePath is relative to the
 * server's storage/ directory root, suitable for storing in the
 * Document table and later serving through an authenticated route.
 */
async function generateRegistrationSlip({ userId, fullName, email, registrationId, registeredAt }) {
  const filename = `registration-${registrationId}.pdf`;
  const filePath = path.join(STORAGE_DIR, filename);

  await new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 56 });
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    // Header band
    doc.rect(0, 0, doc.page.width, 120).fill('#0F1B2D');
    if (fs.existsSync(LOGO_PATH)) {
      try { doc.image(LOGO_PATH, 56, 28, { width: 64, height: 64 }); } catch (_) { /* logo optional */ }
    }
    doc.fillColor('#FAF6EE').fontSize(20).font('Helvetica-Bold')
      .text("Buddha's Path of Equality", 132, 40);
    doc.fillColor('#C6A15B').fontSize(11).font('Helvetica')
      .text('A Journey Towards Peace, Wisdom & Equality', 132, 66);

    doc.moveDown(6);
    doc.fillColor('#0F1B2D').fontSize(18).font('Helvetica-Bold')
      .text('Registration Confirmation', 56, 150);

    doc.moveTo(56, 178).lineTo(doc.page.width - 56, 178).strokeColor('#C6A15B').lineWidth(1).stroke();

    const rows = [
      ['Full Name', fullName],
      ['Registered Email', email],
      ['Registration ID', registrationId],
      ['Registration Date', new Date(registeredAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })],
      ['Verification Status', 'Verified ✓'],
    ];

    let y = 200;
    doc.font('Helvetica').fontSize(12);
    rows.forEach(([label, value]) => {
      doc.fillColor('#6b7380').text(label, 56, y);
      doc.fillColor('#1B2430').font('Helvetica-Bold').text(String(value), 260, y);
      doc.font('Helvetica');
      y += 30;
    });

    y += 20;
    doc.moveTo(56, y).lineTo(doc.page.width - 56, y).strokeColor('#E5E0D4').lineWidth(1).stroke();
    y += 24;

    doc.fillColor('#0F1B2D').fontSize(13).font('Helvetica-Bold')
      .text('🕊️ Welcome to Buddha\'s Path of Equality', 56, y);
    y += 22;
    doc.fillColor('#3C4552').fontSize(11).font('Helvetica')
      .text('Thank you for joining our community dedicated to peace, wisdom, equality and humanity. This document confirms your successful registration and identity verification.', 56, y, { width: doc.page.width - 112 });

    // Footer
    const footerY = doc.page.height - 80;
    doc.moveTo(56, footerY).lineTo(doc.page.width - 56, footerY).strokeColor('#E5E0D4').stroke();
    doc.fillColor('#8b93a0').fontSize(9)
      .text('This document is auto-generated and does not contain any password or verification code.', 56, footerY + 10)
      .text(`User ID: ${userId}`, 56, footerY + 24);

    doc.end();
    stream.on('finish', resolve);
    stream.on('error', reject);
  });

  return { filename, filePath: path.relative(path.join(__dirname, '..', '..', 'storage'), filePath) };
}

module.exports = { generateRegistrationSlip, STORAGE_DIR };
